# USB Replug Dongle Rev.C.1 Cost-Optimized — JLCPCB Release Notes

Generated UTC: 2026-07-18T11:10:31Z

## Supersession

- This Rev.C.1 package supersedes `USB_Replug_Dongle_RevC1_JLCPCB_ResetSafe_20260718` and its full-release archive.
- This reset-safe package removes the CH552-to-CH334 reset crossing, moves TPS2552 FAULT fully into the 5 V domain, and bounds FSUSB42 `/OE` within its 3.3 V control rating.

## Upload Files

- PCB Gerber/Drill archive: `USB_Replug_Dongle_RevC1_JLCPCB_OrderReady_20260718_gerber_drill.zip`
- Assembly archive: `assembly.zip`
- Assembly BOM: `assembly/bom.csv`
- Assembly CPL/POS: `assembly/positions.csv`
- JLC Assembly Notes text: `jlcpcb-assembly-note-500chars.txt`
- Visual checks: `visuals/top-assembly.svg`, `visuals/bottom-copper.svg`
- Mechanical orientation evidence: `reports/connector-orientation-audit.md`
- Reset-domain evidence: `reports/reset-domain-audit.md`

## Board Options To Select At JLCPCB

- PCB type: FR-4 rigid PCB
- Layers: 4
- Board size from Edge.Cuts: 49.5 mm × 21.6 mm
- Assembly side: Top side only
- Assembly mode: Top-side full PCBA using supplied BOM and CPL
- Mechanical direction: J1 USB-C upstream opening faces the left/PC edge; J2 USB-A downstream opening faces the right/DUT edge.
- Connector assembly note: J1 USB-C and J2 USB-A include through-hole/mechanical shield pads in addition to SMT pads; confirm JLCPCB mixed/wave/manual soldering support for these connector pads in the placement/engineering preview.
- Quantity: prototype quantity per order

## Local Validation Result

```json
{
  "gerber_file_count": 16,
  "missing_required_suffixes": [],
  "bom_line_count": 14,
  "bom_placement_ref_count": 29,
  "position_line_count": 29,
  "missing_positions_for_bom_refs": [],
  "extra_positions_not_in_bom": [],
  "blank_lcsc_rows": [],
  "non_top_position_rows": [],
  "non_positive_position_rows": [],
  "board_size_mm": [
    49.5,
    21.6
  ],
  "edge_facing_connector_intent": {
    "J1": "USB-C upstream opening faces left/PC side; KiCad rotation -90/270 deg",
    "J2": "USB-A downstream opening faces right/DUT side; KiCad rotation +90 deg"
  },
  "connector_position_rows": {
    "J1": {
      "Mid X": "3.820000",
      "Mid Y": "10.500000",
      "Rotation": "-90.000000",
      "Layer": "Top"
    },
    "J2": {
      "Mid X": "35.600000",
      "Mid Y": "10.500000",
      "Rotation": "90.000000",
      "Layer": "Top"
    }
  },
  "connector_bom_rows": [
    {
      "Designator": "J1",
      "Footprint": "USB_Replug_Dongle_RevC1:C7507405_USB_C",
      "LCSC Part #": "C7507405",
      "Assembly Notes": "Top SMT/PTH shell; opening at left edge"
    },
    {
      "Designator": "J2",
      "Footprint": "USB_Replug_Dongle_RevC1:C8328_USB_A",
      "LCSC Part #": "C8328",
      "Assembly Notes": "Top SMT/PTH locating holes; opening at right edge"
    }
  ],
  "reset_domain_audit_passed": true,
  "reset_domain_calculated_limits_v": {
    "oe_por_max": 2.6513,
    "oe_release_min": 1.5623,
    "fsusb_control_absolute_max": 3.3,
    "fsusb_vih_min": 1.3
  },
  "jlc_engineering_review_required": [
    "Confirm J1/J2 physical connector orientation in JLC placement preview.",
    "Confirm J1/J2 through-hole/mechanical shield pads are supported by the selected PCBA process or accepted as hand-solder/wave-solder work.",
    "Confirm IC pin-1, U6/U7 ESD orientation, and Y1 placement before payment."
  ],
  "supersedes_release": "USB_Replug_Dongle_RevC1_JLCPCB_ResetSafe_20260718",
  "checks_passed": true
}
```

## Required Human/JLC Preview Checks Before Paying

1. Upload `USB_Replug_Dongle_RevC1_JLCPCB_OrderReady_20260718_gerber_drill.zip` as PCB file and confirm board outline, drill alignment, mask, paste, and silkscreen preview.
2. Enable PCB assembly and upload `bom.csv` plus `positions.csv`.
3. Confirm all BOM rows match LCSC/JLCPCB parts; replace any unavailable parts in the JLC part selection UI.
4. Inspect connector, USB ESD, MCU, hub, data switch, VBUS switch, LDO, and crystal orientation in the JLC placement preview.
5. Confirm J1 opens toward the left PC side and J2 opens toward the right DUT side in the JLC placement preview.
6. Confirm J1/J2 connector through-hole/mechanical shield pads are included in the chosen PCBA process or explicitly accepted as hand-solder/wave-solder work.
7. Keep JLC engineer review enabled; do not waive orientation warnings without checking polarity/pin-1 marks.
8. Re-check live stock/substitution for every `LCSC Part #` immediately before payment; JLC/LCSC stock changes are not stable.

## Known Release Boundaries

- This package is a USB-stick-class Rev.C.1 prototype using a 4-layer board and top-side full assembly.
- Upstream is J1 USB-C receptacle; downstream is J2 USB-A female receptacle. Mechanical openings must face opposite board edges.
- The router-visible VBUS class is 0.25 mm, target current limit is approximately 500 mA, and KiCad DRC/ERC are hard release gates.
- Live stock and final quote are time-sensitive; re-check every selected LCSC part and substitution immediately before payment.
- This local package is not claimed as live-upload validated until the current files are previewed in JLCPCB.
- Firmware is Phase 4 and is not included in this manufacturing archive.
