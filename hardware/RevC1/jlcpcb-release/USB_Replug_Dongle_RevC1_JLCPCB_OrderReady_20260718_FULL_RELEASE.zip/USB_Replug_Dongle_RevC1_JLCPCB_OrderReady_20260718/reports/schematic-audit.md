# Rev.C.1 Schematic Audit

- Fitted references: 29
- Blank fitted LCSC identifiers: none
- Planned regular Extended types: 7 — C111367, C11355, C46506, C5187524, C7507405, C7519, C8328
- Reset-safe target power: TARGET_PWR_EN_N has an external 5.1k pull-up to 5 V; TPS2552 /EN high is OFF.
- Reset-safe target data: R6/R8/R9 are equal 5.1k parts; FSUSB /OE is at most 2.651 V during 5.25 V POR and at least 1.562 V after firmware release, within the 3.3 V control-input limits.
- Reset-safe fault input: TPS2552 FAULT and CH552 P3.0 share the 5 V domain; TI rates the open-drain FAULT node to 7 V absolute maximum and characterizes it at 6.5 V.
- Hub reset: CH334U RESET#/CDP is un-driven as WCH recommends; its internal POR and about-25k pull-up are used. TP8 is manual active-low reset access and CH552 P3.1 is NC.
- U6/U7 pin mapping follows USBLC6-2SC6 flow-through pins 1↔6 and 3↔4, pin 2 GND, pin 5 VBUS; U6 uses the symmetric channels in crossed logical order to prevent a PCB trace crossover.
- CH334U PSELF is tied low for bus-powered identity; ports 3/4, PWREN#/OVCUR#/LED pins, and FSUSB throw 2 are explicit no-connects.
- CH552 programming access exposes VBUS_IN, GND, RST, P1.4, P1.6, and P1.7.
