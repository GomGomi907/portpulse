# Rev.C.1 Connector Orientation Audit

- Verdict: **PASS**
- Board: `USB_Replug_Dongle_RevC1\USB_Replug_Dongle_RevC1.kicad_pcb`
- Evidence: exact project-local footprint geometry plus current KiCad board transforms.

## J1 (C7507405)
- Footprint: `USB_Replug_Dongle_RevC1\USB_Replug_Dongle_RevC1.pretty\C7507405_USB_C.kicad_mod` / `C7507405_USB_C`
- Position / rotation / side: [3.82, 10.5] mm / -90.0° / F.Cu
- Signal-tail average local Y: -2.379 mm
- F.Fab geometry mid local Y: 0.3 mm
- Inferred mating opening: local +Y
- Current opening vector: [-1.0, -0.0]
- Required: -X / left board edge / PC side
- Checks: `{"project_local_footprint_name_matches": true, "position_matches_release_placement": true, "rotation_matches_release_placement": true, "signal_row_is_local_minus_y": true, "opening_faces_required_board_edge": true, "top_side": true}`
- Result: **PASS**

## J2 (C8328)
- Footprint: `USB_Replug_Dongle_RevC1\USB_Replug_Dongle_RevC1.pretty\C8328_USB_A.kicad_mod` / `C8328_USB_A`
- Position / rotation / side: [35.6, 10.5] mm / 90.0° / F.Cu
- Signal-tail average local Y: -1.3 mm
- F.Fab geometry mid local Y: 5.15 mm
- Inferred mating opening: local +Y
- Current opening vector: [1.0, 0.0]
- Required: +X / right board edge / DUT side
- Checks: `{"project_local_footprint_name_matches": true, "position_matches_release_placement": true, "rotation_matches_release_placement": true, "signal_row_is_local_minus_y": true, "opening_faces_required_board_edge": true, "top_side": true}`
- Result: **PASS**
