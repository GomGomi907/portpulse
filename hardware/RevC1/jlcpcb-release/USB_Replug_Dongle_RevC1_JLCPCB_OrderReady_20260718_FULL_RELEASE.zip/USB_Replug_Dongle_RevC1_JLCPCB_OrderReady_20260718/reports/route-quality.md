# Route Quality Audit

## Summary

- Board: `USB_Replug_Dongle_RevC1\USB_Replug_Dongle_RevC1.kicad_pcb`
- Intent: `routing\revc1_routing_intent.json`
- Copper layers: 4
- Footprints: 38
- Track/arc segments: 389
- Vias: 36
- Native arcs: 0
- Total soft score: 910.54 lower is better
- Net class counts: `{'control_gpio': 12, 'crystal_clock': 2, 'ground': 1, 'logic_power': 2, 'usb2_hs_pair': 10, 'usb_fs_internal': 2, 'vbus_power': 2}`
- Pair thresholds: PASS
- Power minimum widths: PASS
- Overall route audit: PASS

## Differential Pair Balance

| Pair | P length mm | N length mm | Skew / max mm | P/N vias | Gate |
|---|---:|---:|---:|---:|---|
| USB_UP_RAW | 3.535 | 4.735 | 1.200 / 1.500 | 0/0 | PASS |
| USB_UP_HUB | 5.486 | 4.736 | 0.750 / 1.000 | 0/0 | PASS |
| MCU_USB_FS | 8.853 | 9.514 | 0.661 / 2.000 | 2/2 | PASS |
| HUB_DUT | 4.727 | 4.671 | 0.056 / 1.000 | 0/0 | PASS |
| DUT_SWITCH | 2.932 | 2.071 | 0.862 / 1.000 | 0/0 | PASS |
| DUT_CONNECTOR | 3.464 | 3.423 | 0.042 / 1.000 | 0/0 | PASS |

## Top Score Contributors

| Net | Soft score |
|---|---:|
| `/GND` | 332.92 |
| `/VBUS_IN` | 121.35 |
| `/3V3` | 105.38 |
| `/HUB_RESET_N` | 54.01 |
| `/TARGET_FAULT_N` | 47.53 |
| `/TARGET_PWR_EN_N` | 46.29 |
| `/TARGET_DATA_OE_N` | 33.98 |
| `/MCU_USB_DM` | 32.01 |
| `/MCU_P17` | 29.42 |
| `/MCU_USB_DP` | 29.35 |
| `/MCU_RST` | 29.29 |
| `/MCU_P16` | 27.94 |
| `/MCU_P14` | 26.84 |
| `/HUB_XI` | 2.15 |
| `/CC1` | 1.47 |

## Warnings

- none

## Limitations

- Pair length is summed from routed copper; the USB-C raw A/B duplicate-pad branch total is conservative and is not a single-trunk propagation measurement.
- Uncoupled differential-pair length is not yet geometrically extracted; this audit measures pair length/via balance and corner quality first.
- Impedance compliance is policy/config based until selected JLCPCB stack-up width/gap is frozen.
